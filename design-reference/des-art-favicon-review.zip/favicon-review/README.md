# Des-art favicon review package

- compact: 24 px and under
- detailed: above 24 px
- dark mark: #2F3133 on #FFFFFF
- white mark: #FFFFFF on #161819
- favicon.svg: adaptive light/dark browser favicon
- favicon.ico: fallback with 16/24 compact and 32/48 detailed dark marks
- Apple and PWA candidates are generated in both approved colorways for selection before integration.
